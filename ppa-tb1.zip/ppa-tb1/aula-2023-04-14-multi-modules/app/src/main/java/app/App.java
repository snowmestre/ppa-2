package app;

import java.util.List;
import java.util.Optional;
import java.math.BigDecimal;
import java.time.LocalDate;

import memoria.persistence.AlunoRepository;
import memoria.persistence.BoletoRepository;
import memoria.persistence.CursoRepository;
import memoria.persistence.MatriculaRepository;
import memoria.persistence.ParametroRepository;
import modelo.entidade.Aluno;
import modelo.entidade.Curso;
import modelo.entidade.Boleto;
import modelo.service.MatriculaService;
import modelo.service.ServiceException;
import persistence.IAlunoRepository;
import persistence.IBoletoRepository;
import persistence.ICursoRepository;
import persistence.IMatriculaRepository;
import persistence.IParametroRepository;

public class App {
    
    public static void main(String[] args) {

        IAlunoRepository alunoRepository = new AlunoRepository();
        ICursoRepository cursoRepository = new CursoRepository();
        IParametroRepository paramRepository = new ParametroRepository();
        IMatriculaRepository matriculaRepository = new MatriculaRepository();
        IBoletoRepository boletoRepository = new BoletoRepository();
        

        MatriculaService matriculaService = new MatriculaService(
            alunoRepository, 
            cursoRepository,
            paramRepository,
            boletoRepository,
            matriculaRepository);

            Aluno ge = new Aluno();
            ge.setId(1);
            ge.setNome("Geraldo");
            ge.setCpf("00800800808");
            ge.setEmail("gege@email.com");
            ge.setDataNascimento(LocalDate.of(1984,05,21));
            alunoRepository.insert(ge);
            System.out.println(alunoRepository.findByCpf("00800800808"));

            
            Curso tads = new Curso();
            tads.setCodigo(001);
            tads.setNome("Tads");
            tads.setEmenta("Desenvolvimento e Sofrimento");
            tads.setCargaHoraria(1200);
            tads.setVagas(30);
            tads.setInscritos(30);
            tads.setDataInicio(LocalDate.now());
            tads.setIdadeMinima(18);
            
            cursoRepository.save(tads);
            System.out.println(cursoRepository.findByCodigo(001));

            Boleto geBoleto = new Boleto();
            geBoleto.setCodigo(1);
            geBoleto.setValor(BigDecimal.valueOf(600));
            geBoleto.setVencimento(LocalDate.of(2021,05,21));
            geBoleto.setPago(true);
            geBoleto.setCpf("00800800808");            
            
            boletoRepository.insert(geBoleto);

            List<Boleto> listBoletos = boletoRepository.findBoletosByCpf("00800800808");

            listBoletos.forEach(System.out::println);

   
            matriculaService.matricular("00800800808", 001);
            System.out.println("Matricula Realizada " + matriculaRepository.findAll());





         /*Matricula m = matriculaService.matricular("12345678901", 123);
        Aluno aluno = new Aluno(Integer.valueOf(1), "12345678912", "Marcos", "marcos@gmail.com", LocalDate.of(1998, 10, 31));
        alunoRepository.insert(aluno);
        
        Curso curso = new Curso(Integer.valueOf(123), "PPA", "Varias paradas", Integer.valueOf(100),Integer.valueOf(40), Integer.valueOf(0), LocalDate.of(2023, 12, 15), 15);
        cursoRepository.insert(curso);

        Boleto boleto = new Boleto(Integer.valueOf(1), BigDecimal.valueOf(100.0), LocalDate.of(2023, 12, 30), true, "12345678912");
        boletoRepository.insert(boleto);

        */
        
        
    }

}
