package app;

public @interface Test {

}
