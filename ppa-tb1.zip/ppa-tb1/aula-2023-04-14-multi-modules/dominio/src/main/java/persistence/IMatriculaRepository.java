package persistence;

import modelo.entidade.Matricula;
import java.util.List;

public interface IMatriculaRepository {

	void save(Matricula matricula);

	List<Matricula> findAll();
  
}
