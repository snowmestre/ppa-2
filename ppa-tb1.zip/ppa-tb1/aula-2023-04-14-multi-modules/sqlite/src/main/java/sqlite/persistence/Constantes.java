package sqlite.persistence;

public final class Constantes {
    private Constantes() {}
    public final static String DB_NAME = "mochinho.db";
}