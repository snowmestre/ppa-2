package memoria.persistence;

import java.util.Optional;
import persistence.IParametroRepository;

public class ParametroRepository implements IParametroRepository {
  

  @Override
  public Optional<String> findParam(String nome) {
    // Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'findParam'");
  }
  
}
